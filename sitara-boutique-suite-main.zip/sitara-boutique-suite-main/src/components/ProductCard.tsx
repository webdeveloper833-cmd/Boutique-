import { Link } from "@tanstack/react-router";
import { Eye, ShoppingBag } from "lucide-react";
import { type Product, formatPKR } from "@/lib/products";
import { useCart } from "@/lib/cart";

export function ProductCard({ product }: { product: Product }) {
  const { add } = useCart();
  return (
    <div className="group relative bg-card rounded-sm overflow-hidden transition-all duration-500 hover:luxury-shadow">
      <Link to="/product/$id" params={{ id: product.id }} className="block relative aspect-[4/5] overflow-hidden bg-secondary">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-[1200ms] group-hover:scale-110"
        />
        {product.badge && (
          <span className="absolute top-3 left-3 bg-primary text-cream text-[10px] tracking-widest px-3 py-1 rounded-sm font-medium">
            {product.badge}
          </span>
        )}
        <div className="absolute inset-x-0 bottom-0 p-3 flex gap-2 translate-y-full group-hover:translate-y-0 transition-transform duration-500">
          <button
            onClick={(e) => { e.preventDefault(); add(product.id); }}
            className="flex-1 bg-primary text-cream py-2.5 text-xs uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-gold hover:text-primary transition"
          >
            <ShoppingBag size={14} /> Add to Cart
          </button>
          <Link
            to="/product/$id"
            params={{ id: product.id }}
            className="bg-cream text-primary px-3 flex items-center justify-center hover:bg-gold transition"
            aria-label="Quick view"
          >
            <Eye size={16} />
          </Link>
        </div>
      </Link>
      <div className="p-4 text-center">
        <Link to="/product/$id" params={{ id: product.id }}>
          <h3 className="font-serif text-base text-foreground line-clamp-1">{product.name}</h3>
        </Link>
        <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground mt-1">{product.category}</p>
        <div className="mt-2 flex items-center justify-center gap-2">
          <span className="font-semibold text-primary">{formatPKR(product.price)}</span>
          {product.originalPrice && (
            <span className="text-xs line-through text-muted-foreground">{formatPKR(product.originalPrice)}</span>
          )}
        </div>
      </div>
    </div>
  );
}