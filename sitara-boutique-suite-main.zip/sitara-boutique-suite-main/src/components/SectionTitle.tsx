export function SectionTitle({ eyebrow, title, urdu, center = true }: { eyebrow?: string; title: string; urdu?: string; center?: boolean }) {
  return (
    <div className={center ? "text-center max-w-2xl mx-auto mb-12" : "mb-12"}>
      {eyebrow && (
        <p className="text-xs uppercase tracking-[0.4em] text-gold mb-3">{eyebrow}</p>
      )}
      <h2 className="font-serif text-3xl md:text-5xl text-primary leading-tight">{title}</h2>
      {urdu && (
        <p className="font-urdu text-xl md:text-2xl text-foreground/70 mt-3" style={{ direction: "rtl" }}>{urdu}</p>
      )}
      <div className={`gold-divider w-24 mt-5 ${center ? "mx-auto" : ""}`} />
    </div>
  );
}