import { whatsappLink } from "@/lib/products";

export function WhatsAppFab() {
  return (
    <a
      href={whatsappLink("Assalam o Alaikum, I would like to know more about your collection.")}
      target="_blank"
      rel="noreferrer"
      aria-label="Chat on WhatsApp"
      className="fixed bottom-5 right-5 z-40 w-14 h-14 rounded-full bg-whatsapp text-white shadow-2xl flex items-center justify-center hover:scale-110 transition-transform"
    >
      <svg viewBox="0 0 24 24" width="26" height="26" fill="currentColor"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 2.1.55 4.15 1.6 5.95L2 22l4.25-1.11a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.84 9.84 0 0 0 12.04 2zm5.78 14.13c-.25.7-1.45 1.34-2.02 1.4-.55.06-1.24.09-2-.13-.46-.13-1.06-.33-1.83-.66-3.22-1.39-5.32-4.63-5.48-4.84-.16-.21-1.31-1.74-1.31-3.32 0-1.58.83-2.36 1.12-2.68.29-.33.64-.41.85-.41.21 0 .43.0.61.01.2.01.46-.07.72.55.27.65.91 2.23.99 2.39.08.16.13.35.03.55-.1.21-.15.33-.29.51-.15.18-.31.4-.44.54-.15.16-.3.33-.13.65.16.32.74 1.22 1.59 1.98 1.09.97 2.01 1.27 2.33 1.41.32.13.5.11.69-.07.18-.18.79-.92.99-1.24.21-.32.41-.27.7-.16.29.1 1.85.87 2.16 1.03.32.16.53.24.61.37.08.13.08.75-.17 1.45z"/></svg>
    </a>
  );
}