export function Logo({ stacked = false }: { stacked?: boolean }) {
  return (
    <div className={stacked ? "text-center" : "flex items-center gap-3"}>
      <div className={stacked ? "" : "flex flex-col items-end leading-none"}>
        <span
          className="font-urdu text-2xl md:text-3xl text-primary font-semibold"
          style={{ direction: "rtl" }}
        >
          نیو ستارہ بوتیک سینٹر
        </span>
        <span className="font-serif text-[10px] md:text-xs uppercase tracking-[0.25em] text-gold mt-0.5">
          New Sitara Boutique Center
        </span>
      </div>
    </div>
  );
}