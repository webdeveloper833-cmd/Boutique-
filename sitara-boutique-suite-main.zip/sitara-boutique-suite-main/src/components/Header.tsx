import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, Search, ShoppingBag, X } from "lucide-react";
import { Logo } from "./Logo";
import { useCart } from "@/lib/cart";
import { whatsappLink } from "@/lib/products";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/shop", label: "Shop" },
  { to: "/categories", label: "Categories" },
  { to: "/about", label: "About Us" },
  { to: "/contact", label: "Contact" },
] as const;

export function Header() {
  const [open, setOpen] = useState(false);
  const { count } = useCart();

  return (
    <header className="sticky top-0 z-50 bg-cream/90 backdrop-blur-md border-b border-gold/20">
      <div className="hidden md:block bg-primary text-cream text-xs">
        <div className="container mx-auto px-6 py-2 flex items-center justify-between">
          <span className="tracking-wide">Free Delivery on Orders Above Rs. 5,000 — Daharanwala, Pakistan</span>
          <a href={whatsappLink("Assalam o Alaikum, I want to order from New Sitara Boutique.")} className="text-gold hover:text-gold-soft transition">
            WhatsApp: +92 300 0000000
          </a>
        </div>
      </div>
      <div className="container mx-auto px-4 md:px-6 h-20 flex items-center justify-between gap-4">
        <Link to="/" className="shrink-0">
          <Logo />
        </Link>
        <nav className="hidden lg:flex items-center gap-8">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="relative text-sm uppercase tracking-[0.18em] text-foreground/80 hover:text-primary transition story-link"
              activeProps={{ className: "text-primary font-semibold" }}
              activeOptions={{ exact: n.to === "/" }}
            >
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2 md:gap-3">
          <button aria-label="Search" className="p-2 rounded-full hover:bg-secondary transition text-foreground/80">
            <Search size={20} />
          </button>
          <Link to="/cart" className="p-2 rounded-full hover:bg-secondary transition text-foreground/80 relative" aria-label="Cart">
            <ShoppingBag size={20} />
            {count > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-gold text-primary text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">
                {count}
              </span>
            )}
          </Link>
          <a
            href={whatsappLink("Assalam o Alaikum, I want to place an order.")}
            target="_blank"
            rel="noreferrer"
            className="hidden md:inline-flex items-center gap-2 bg-whatsapp text-white px-4 py-2 rounded-full text-sm font-medium hover:opacity-90 transition"
          >
            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 2.1.55 4.15 1.6 5.95L2 22l4.25-1.11a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.84 9.84 0 0 0 12.04 2zm0 18.05a8.13 8.13 0 0 1-4.15-1.14l-.3-.18-2.52.66.67-2.46-.19-.31a8.16 8.16 0 0 1-1.25-4.33c0-4.49 3.66-8.15 8.16-8.15 2.18 0 4.23.85 5.77 2.39a8.12 8.12 0 0 1 2.39 5.77c0 4.49-3.66 8.15-8.15 8.15z"/></svg>
            Order on WhatsApp
          </a>
          <button onClick={() => setOpen((v) => !v)} className="lg:hidden p-2" aria-label="Menu">
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>
      {open && (
        <div className="lg:hidden border-t border-gold/20 bg-cream animate-float-up">
          <nav className="flex flex-col p-6 gap-4">
            {NAV.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                onClick={() => setOpen(false)}
                className="text-base uppercase tracking-widest text-foreground/90"
                activeProps={{ className: "text-primary font-semibold" }}
              >
                {n.label}
              </Link>
            ))}
            <a
              href={whatsappLink("Assalam o Alaikum, I want to place an order.")}
              target="_blank"
              rel="noreferrer"
              className="mt-2 inline-flex items-center justify-center gap-2 bg-whatsapp text-white px-4 py-3 rounded-full font-medium"
            >
              Order on WhatsApp
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}