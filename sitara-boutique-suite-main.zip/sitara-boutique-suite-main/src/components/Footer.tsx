import { Link } from "@tanstack/react-router";
import { Facebook, Instagram, Mail, MapPin, Phone, Youtube } from "lucide-react";
import { Logo } from "./Logo";

export function Footer() {
  return (
    <footer className="bg-primary text-cream/90 mt-24">
      <div className="container mx-auto px-6 py-16 grid gap-12 md:grid-cols-4">
        <div className="md:col-span-1 space-y-4">
          <div className="[&_*]:!text-cream">
            <Logo />
          </div>
          <p className="text-sm leading-relaxed text-cream/70">
            A trusted Pakistani fashion boutique bringing premium stitched and unstitched collections for the whole family — from Daharanwala to your doorstep.
          </p>
          <div className="flex gap-3 pt-2">
            {[Facebook, Instagram, Youtube].map((Icon, i) => (
              <a
                key={i}
                href="#"
                className="w-9 h-9 rounded-full border border-gold/40 flex items-center justify-center hover:bg-gold hover:text-primary transition"
                aria-label="Social"
              >
                <Icon size={16} />
              </a>
            ))}
          </div>
        </div>
        <div>
          <h4 className="font-serif text-lg text-gold mb-4">Quick Links</h4>
          <ul className="space-y-2 text-sm">
            {[
              ["/", "Home"],
              ["/shop", "Shop"],
              ["/categories", "Categories"],
              ["/about", "About Us"],
              ["/contact", "Contact"],
            ].map(([to, label]) => (
              <li key={to}>
                <Link to={to} className="hover:text-gold transition">{label}</Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="font-serif text-lg text-gold mb-4">Categories</h4>
          <ul className="space-y-2 text-sm">
            {["Ladies", "Gents", "Stitched", "Unstitched", "Seasonal", "New Arrivals"].map((c) => (
              <li key={c}>
                <Link to="/shop" className="hover:text-gold transition">{c}</Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="font-serif text-lg text-gold mb-4">Get in Touch</h4>
          <ul className="space-y-3 text-sm">
            <li className="flex gap-2"><MapPin size={16} className="text-gold mt-0.5 shrink-0" /> Main Bazaar, Daharanwala, Pakistan</li>
            <li className="flex gap-2"><Phone size={16} className="text-gold mt-0.5 shrink-0" /> +92 300 0000000</li>
            <li className="flex gap-2"><Mail size={16} className="text-gold mt-0.5 shrink-0" /> info@newsitara.com</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-gold/20">
        <div className="container mx-auto px-6 py-5 flex flex-col md:flex-row items-center justify-between gap-2 text-xs text-cream/60">
          <p>© {new Date().getFullYear()} New Sitara Boutique Center. All rights reserved.</p>
          <p className="font-urdu text-base text-gold" style={{ direction: "rtl" }}>نیو ستارہ بوتیک سینٹر</p>
        </div>
      </div>
    </footer>
  );
}