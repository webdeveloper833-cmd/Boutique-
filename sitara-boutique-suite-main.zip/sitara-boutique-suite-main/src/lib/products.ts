import p1 from "@/assets/p1.jpg";
import p2 from "@/assets/p2.jpg";
import p3 from "@/assets/p3.jpg";
import p4 from "@/assets/p4.jpg";
import p5 from "@/assets/p5.jpg";
import p6 from "@/assets/p6.jpg";
import p7 from "@/assets/p7.jpg";
import catLadies from "@/assets/cat-ladies.jpg";
import catGents from "@/assets/cat-gents.jpg";
import catStitched from "@/assets/cat-stitched.jpg";
import catUnstitched from "@/assets/cat-unstitched.jpg";
import catSeasonal from "@/assets/cat-seasonal.jpg";
import catArrivals from "@/assets/cat-arrivals.jpg";

export type Product = {
  id: string;
  name: string;
  nameUr?: string;
  category: "ladies" | "gents" | "stitched" | "unstitched" | "seasonal" | "arrivals";
  price: number;
  originalPrice?: number;
  image: string;
  badge?: string;
  bestSeller?: boolean;
  description: string;
};

export const CATEGORIES = [
  { slug: "ladies", name: "Ladies Collection", nameUr: "خواتین کلیکشن", image: catLadies, count: 86 },
  { slug: "gents", name: "Gents Collection", nameUr: "مردانہ کلیکشن", image: catGents, count: 54 },
  { slug: "stitched", name: "Stitched Collection", nameUr: "سلا ہوا کلیکشن", image: catStitched, count: 72 },
  { slug: "unstitched", name: "Unstitched Collection", nameUr: "بغیر سلا کلیکشن", image: catUnstitched, count: 95 },
  { slug: "seasonal", name: "Seasonal Collection", nameUr: "موسمی کلیکشن", image: catSeasonal, count: 38 },
  { slug: "arrivals", name: "New Arrivals", nameUr: "نئی آمد", image: catArrivals, count: 24 },
] as const;

export const PRODUCTS: Product[] = [
  {
    id: "noor-gold-kameez",
    name: "Noor Gold Embroidered Kameez",
    nameUr: "نور گولڈ کڑھائی کرتا",
    category: "ladies",
    price: 6499,
    originalPrice: 8999,
    image: p1,
    badge: "28% OFF",
    bestSeller: true,
    description:
      "Hand-embroidered ivory kameez with intricate antique gold zari work. Premium lawn fabric, tailored for an elegant silhouette suitable for weddings and Eid occasions.",
  },
  {
    id: "emerald-anarkali",
    name: "Emerald Festive Anarkali",
    nameUr: "زمرد انارکلی",
    category: "ladies",
    price: 12999,
    originalPrice: 16500,
    image: p2,
    badge: "BESTSELLER",
    bestSeller: true,
    description:
      "Floor-length anarkali in deep emerald silk with gold thread embroidery on bodice and hem. Includes matching net dupatta and inner.",
  },
  {
    id: "classic-cream-kurta",
    name: "Classic Cream Cotton Kurta",
    nameUr: "کلاسک کریم کرتا",
    category: "gents",
    price: 3499,
    originalPrice: 4500,
    image: p3,
    description:
      "Crisp cream cotton kurta with handcrafted brass buttons. A staple wardrobe piece for any formal or casual occasion.",
  },
  {
    id: "ivory-lawn-3pc",
    name: "Ivory Lawn 3-Piece Unstitched",
    nameUr: "آئیوری لان تھری پیس",
    category: "unstitched",
    price: 4299,
    originalPrice: 5500,
    image: p4,
    badge: "SALE",
    description:
      "Premium ivory lawn three-piece with delicate gold motif print. Includes shirt, dupatta and trouser fabric ready for stitching.",
  },
  {
    id: "royal-bridal-dupatta",
    name: "Royal Bridal Dupatta Set",
    nameUr: "شاہی دلہن دوپٹہ",
    category: "seasonal",
    price: 18999,
    originalPrice: 24999,
    image: p5,
    badge: "LIMITED",
    bestSeller: true,
    description:
      "Heritage bridal dupatta with heavy gold zardozi work. Statement piece designed for the modern Pakistani bride.",
  },
  {
    id: "emerald-everyday-kurti",
    name: "Emerald Everyday Kurti",
    nameUr: "زمرد ایوری ڈے کرتی",
    category: "stitched",
    price: 2999,
    originalPrice: 3999,
    image: p6,
    description:
      "Minimal emerald kurti with subtle gold trims at neckline, sleeves and hem. Pairs effortlessly with white trousers.",
  },
  {
    id: "gents-waistcoat",
    name: "Heritage Gents Waistcoat",
    nameUr: "ہیریٹیج واسکٹ",
    category: "gents",
    price: 7999,
    originalPrice: 9999,
    image: p7,
    badge: "NEW",
    bestSeller: true,
    description:
      "Deep green jamawar waistcoat with hand-embroidered collar and gold piping. Perfect over a cream kurta for weddings.",
  },
];

export const WHATSAPP_NUMBER = "923000000000"; // +92 300 0000000 placeholder

export function whatsappLink(message: string) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

export function formatPKR(n: number) {
  return "Rs. " + n.toLocaleString("en-PK");
}