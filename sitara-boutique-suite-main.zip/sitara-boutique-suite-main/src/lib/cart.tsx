import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { PRODUCTS, type Product } from "./products";

export type CartItem = { product: Product; qty: number; size?: string };

type CartCtx = {
  items: CartItem[];
  add: (id: string, qty?: number, size?: string) => void;
  remove: (id: string) => void;
  setQty: (id: string, qty: number) => void;
  clear: () => void;
  count: number;
  total: number;
};

const Ctx = createContext<CartCtx | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem("sitara-cart");
      if (!raw) return;
      const ids: { id: string; qty: number; size?: string }[] = JSON.parse(raw);
      const restored = ids
        .map((i) => {
          const p = PRODUCTS.find((x) => x.id === i.id);
          return p ? { product: p, qty: i.qty, size: i.size } : null;
        })
        .filter(Boolean) as CartItem[];
      setItems(restored);
    } catch {}
  }, []);

  useEffect(() => {
    localStorage.setItem(
      "sitara-cart",
      JSON.stringify(items.map((i) => ({ id: i.product.id, qty: i.qty, size: i.size }))),
    );
  }, [items]);

  const add: CartCtx["add"] = (id, qty = 1, size) => {
    const product = PRODUCTS.find((p) => p.id === id);
    if (!product) return;
    setItems((prev) => {
      const existing = prev.find((i) => i.product.id === id);
      if (existing) return prev.map((i) => (i.product.id === id ? { ...i, qty: i.qty + qty } : i));
      return [...prev, { product, qty, size }];
    });
  };

  const value: CartCtx = {
    items,
    add,
    remove: (id) => setItems((p) => p.filter((i) => i.product.id !== id)),
    setQty: (id, qty) =>
      setItems((p) => p.map((i) => (i.product.id === id ? { ...i, qty: Math.max(1, qty) } : i))),
    clear: () => setItems([]),
    count: items.reduce((a, b) => a + b.qty, 0),
    total: items.reduce((a, b) => a + b.qty * b.product.price, 0),
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCart() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useCart must be used inside CartProvider");
  return c;
}