import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { Minus, Plus, ShieldCheck, ShoppingBag, Truck } from "lucide-react";
import { PRODUCTS, formatPKR, whatsappLink } from "@/lib/products";
import { useCart } from "@/lib/cart";
import { ProductCard } from "@/components/ProductCard";

export const Route = createFileRoute("/product/$id")({
  head: ({ params }) => {
    const p = PRODUCTS.find((x) => x.id === params.id);
    return {
      meta: [
        { title: `${p?.name ?? "Product"} — New Sitara Boutique` },
        { name: "description", content: p?.description.slice(0, 160) ?? "Premium Pakistani fashion product." },
        { property: "og:title", content: p?.name ?? "Product" },
        { property: "og:description", content: p?.description.slice(0, 160) ?? "Premium Pakistani fashion." },
        { property: "og:image", content: p?.image ?? "" },
      ],
    };
  },
  component: ProductPage,
  notFoundComponent: () => (
    <div className="container mx-auto px-6 py-32 text-center">
      <h1 className="font-serif text-3xl text-primary">Product not found</h1>
      <Link to="/shop" className="inline-flex mt-6 bg-primary text-cream px-7 py-3 rounded-full">Back to Shop</Link>
    </div>
  ),
  loader: ({ params }) => {
    const p = PRODUCTS.find((x) => x.id === params.id);
    if (!p) throw notFound();
    return { product: p };
  },
});

const SIZES = ["S", "M", "L", "XL"];

function ProductPage() {
  const { product } = Route.useLoaderData();
  const { add } = useCart();
  const [size, setSize] = useState("M");
  const [qty, setQty] = useState(1);
  const related = PRODUCTS.filter((p) => p.id !== product.id && p.category === product.category).slice(0, 4);

  return (
    <div>
      <section className="container mx-auto px-6 py-12">
        <p className="text-xs text-muted-foreground mb-6">
          <Link to="/" className="hover:text-primary">Home</Link> /{" "}
          <Link to="/shop" className="hover:text-primary">Shop</Link> /{" "}
          <span className="text-primary">{product.name}</span>
        </p>

        <div className="grid lg:grid-cols-2 gap-10">
          <div>
            <div className="aspect-[4/5] rounded-sm overflow-hidden bg-secondary luxury-shadow">
              <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
            </div>
            <div className="grid grid-cols-4 gap-3 mt-3">
              {[product.image, product.image, product.image, product.image].map((src, i) => (
                <div key={i} className="aspect-square rounded-sm overflow-hidden border border-border hover:border-gold transition cursor-pointer">
                  <img src={src} alt="" className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          </div>

          <div>
            {product.badge && <span className="inline-block bg-gold text-primary text-[10px] tracking-widest px-3 py-1 mb-4">{product.badge}</span>}
            <h1 className="font-serif text-3xl md:text-5xl text-primary">{product.name}</h1>
            {product.nameUr && (
              <p className="font-urdu text-2xl text-foreground/70 mt-2" style={{ direction: "rtl" }}>{product.nameUr}</p>
            )}
            <div className="gold-divider w-24 my-5" />
            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-semibold text-primary">{formatPKR(product.price)}</span>
              {product.originalPrice && (
                <span className="text-lg line-through text-muted-foreground">{formatPKR(product.originalPrice)}</span>
              )}
            </div>
            <p className="text-foreground/75 mt-6 leading-relaxed">{product.description}</p>

            <div className="mt-7">
              <p className="text-sm uppercase tracking-widest text-foreground/70 mb-3">Size</p>
              <div className="flex gap-2">
                {SIZES.map((s) => (
                  <button
                    key={s}
                    onClick={() => setSize(s)}
                    className={`w-12 h-12 rounded-sm border transition ${size === s ? "bg-primary text-cream border-primary" : "border-border hover:border-gold"}`}
                  >{s}</button>
                ))}
              </div>
            </div>

            <div className="mt-6">
              <p className="text-sm uppercase tracking-widest text-foreground/70 mb-3">Quantity</p>
              <div className="inline-flex items-center border border-border rounded-sm">
                <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="p-3 hover:bg-secondary"><Minus size={14} /></button>
                <span className="px-5">{qty}</span>
                <button onClick={() => setQty((q) => q + 1)} className="p-3 hover:bg-secondary"><Plus size={14} /></button>
              </div>
            </div>

            <div className="flex flex-wrap gap-3 mt-8">
              <button
                onClick={() => add(product.id, qty, size)}
                className="flex-1 min-w-[200px] inline-flex items-center justify-center gap-2 bg-primary text-cream px-7 py-3.5 rounded-full font-medium hover:bg-gold hover:text-primary transition"
              >
                <ShoppingBag size={18} /> Add to Cart
              </button>
              <a
                href={whatsappLink(`I want to order: ${product.name} (Size ${size}, Qty ${qty}) — ${formatPKR(product.price * qty)}`)}
                target="_blank"
                rel="noreferrer"
                className="flex-1 min-w-[200px] inline-flex items-center justify-center gap-2 bg-whatsapp text-white px-7 py-3.5 rounded-full font-medium hover:opacity-90 transition"
              >
                Buy via WhatsApp
              </a>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-8 text-sm">
              <div className="flex items-center gap-2 text-foreground/70"><Truck size={16} className="text-gold" /> Fast nationwide delivery</div>
              <div className="flex items-center gap-2 text-foreground/70"><ShieldCheck size={16} className="text-gold" /> Quality guaranteed</div>
            </div>
          </div>
        </div>
      </section>

      {related.length > 0 && (
        <section className="bg-secondary/50 py-20 mt-10">
          <div className="container mx-auto px-6">
            <h2 className="font-serif text-3xl md:text-4xl text-primary text-center mb-12">You May Also Love</h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
              {related.map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}