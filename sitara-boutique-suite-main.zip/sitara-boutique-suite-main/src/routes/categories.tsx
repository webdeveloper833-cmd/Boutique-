import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { CATEGORIES } from "@/lib/products";
import { SectionTitle } from "@/components/SectionTitle";

export const Route = createFileRoute("/categories")({
  head: () => ({
    meta: [
      { title: "Categories — New Sitara Boutique Center" },
      { name: "description", content: "Browse all fashion categories — ladies, gents, stitched, unstitched, seasonal and new arrivals." },
      { property: "og:title", content: "Categories — New Sitara Boutique" },
      { property: "og:description", content: "Browse all fashion categories." },
    ],
  }),
  component: Categories,
});

function Categories() {
  return (
    <div>
      <section className="bg-primary text-cream py-16">
        <div className="container mx-auto px-6 text-center">
          <p className="text-xs uppercase tracking-[0.4em] text-gold mb-2">Discover</p>
          <h1 className="font-serif text-4xl md:text-6xl">All Categories</h1>
          <p className="font-urdu text-xl mt-2 text-gold-soft" style={{ direction: "rtl" }}>تمام کلیکشنز</p>
        </div>
      </section>

      <section className="container mx-auto px-6 py-16">
        <SectionTitle eyebrow="Curated" title="Shop by Collection" urdu="کلیکشن کے مطابق خریداری کریں" />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {CATEGORIES.map((c) => (
            <Link
              key={c.slug}
              to="/shop"
              className="group relative aspect-[4/5] overflow-hidden rounded-sm"
            >
              <img src={c.image} alt={c.name} loading="lazy" className="w-full h-full object-cover transition-transform duration-[1500ms] group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-primary via-primary/40 to-transparent" />
              <div className="absolute inset-0 p-7 flex flex-col justify-end text-cream">
                <p className="font-urdu text-2xl text-gold-soft" style={{ direction: "rtl" }}>{c.nameUr}</p>
                <h3 className="font-serif text-3xl">{c.name}</h3>
                <p className="text-sm text-cream/70 mt-1">{c.count} products available</p>
                <span className="inline-flex items-center gap-1 text-xs uppercase tracking-widest text-gold mt-4 group-hover:gap-2 transition-all">
                  Browse <ArrowRight size={12} />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}