import { createFileRoute, Link } from "@tanstack/react-router";
import { Award, Heart, Sparkles } from "lucide-react";
import showcase from "@/assets/showcase-family.jpg";
import { SectionTitle } from "@/components/SectionTitle";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us — New Sitara Boutique Center" },
      { name: "description", content: "Learn about New Sitara Boutique Center, a trusted Pakistani fashion boutique in Daharanwala." },
      { property: "og:title", content: "About — New Sitara Boutique" },
      { property: "og:description", content: "Trusted Pakistani fashion boutique in Daharanwala." },
    ],
  }),
  component: About,
});

function About() {
  return (
    <div>
      <section className="bg-primary text-cream py-16">
        <div className="container mx-auto px-6 text-center">
          <p className="text-xs uppercase tracking-[0.4em] text-gold mb-2">Our Story</p>
          <h1 className="font-serif text-4xl md:text-6xl">About Us</h1>
          <p className="font-urdu text-xl mt-2 text-gold-soft" style={{ direction: "rtl" }}>ہمارے بارے میں</p>
        </div>
      </section>

      <section className="container mx-auto px-6 py-20 grid lg:grid-cols-2 gap-12 items-center">
        <div className="relative aspect-[4/5] rounded-sm overflow-hidden luxury-shadow">
          <img src={showcase} alt="Boutique family" className="w-full h-full object-cover" loading="lazy" />
        </div>
        <div>
          <p className="text-xs uppercase tracking-[0.4em] text-gold mb-3">Est. Daharanwala</p>
          <h2 className="font-serif text-3xl md:text-5xl text-primary leading-tight">A Boutique Built on Trust, Craft & Care</h2>
          <div className="gold-divider w-24 my-6" />
          <p className="text-foreground/75 leading-relaxed">
            New Sitara Boutique Center began with a simple belief — every Pakistani family deserves clothing that feels as good as it looks. From hand-embroidered formal wear to everyday essentials, every piece in our collection is chosen with care, checked for quality, and priced with honesty.
          </p>
          <p className="text-foreground/75 leading-relaxed mt-4">
            Based in Daharanwala, we serve customers across Pakistan with fast delivery and personal WhatsApp support — bringing the warmth of a local boutique to your doorstep.
          </p>
          <p className="font-urdu text-xl text-foreground/75 leading-loose mt-6" style={{ direction: "rtl" }}>
            ہمارا مقصد ہر پاکستانی خاندان کو معیاری، خوبصورت اور قابلِ اعتماد فیشن فراہم کرنا ہے۔
          </p>
        </div>
      </section>

      <section className="bg-secondary/50 py-20">
        <div className="container mx-auto px-6">
          <SectionTitle eyebrow="Our Values" title="What We Stand For" />
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: Award, title: "Uncompromised Quality", desc: "Premium fabrics, refined finishing, lasting craftsmanship." },
              { icon: Heart, title: "Customer First", desc: "Personal service, honest advice, and lifetime support." },
              { icon: Sparkles, title: "Modern Heritage", desc: "Where Pakistani tradition meets contemporary design." },
            ].map((v) => (
              <div key={v.title} className="bg-card p-8 rounded-sm border border-border text-center hover:border-gold transition">
                <div className="w-14 h-14 mx-auto rounded-full bg-primary text-cream flex items-center justify-center mb-4">
                  <v.icon size={24} />
                </div>
                <h3 className="font-serif text-xl text-primary">{v.title}</h3>
                <p className="text-sm text-foreground/70 mt-2">{v.desc}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link to="/shop" className="inline-flex items-center gap-2 bg-primary text-cream px-7 py-3 rounded-full hover:bg-gold hover:text-primary transition">
              Explore Collection
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}