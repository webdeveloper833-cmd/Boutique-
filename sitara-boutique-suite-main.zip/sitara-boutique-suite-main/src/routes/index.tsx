import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Award, HeadphonesIcon, Shield, ShoppingBag, Sparkles, Star, Truck } from "lucide-react";
import hero from "@/assets/hero-ladies.jpg";
import showcase from "@/assets/showcase-family.jpg";
import { CATEGORIES, PRODUCTS, whatsappLink } from "@/lib/products";
import { ProductCard } from "@/components/ProductCard";
import { SectionTitle } from "@/components/SectionTitle";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "New Sitara Boutique Center — Premium Pakistani Fashion" },
      { name: "description", content: "Shop premium ladies, gents, stitched and unstitched Pakistani fashion at New Sitara Boutique Center, Daharanwala." },
      { property: "og:title", content: "New Sitara Boutique Center" },
      { property: "og:description", content: "Premium Pakistani fashion for every occasion." },
    ],
  }),
  component: Index,
});

function Index() {
  const featured = PRODUCTS.slice(0, 4);
  const bestSellers = PRODUCTS.filter((p) => p.bestSeller);

  return (
    <div>
      {/* HERO */}
      <section className="relative bg-cream overflow-hidden">
        <div className="container mx-auto px-6 grid lg:grid-cols-2 gap-10 lg:gap-16 items-center py-12 lg:py-20">
          <div className="order-2 lg:order-1 animate-float-up">
            <p className="text-xs uppercase tracking-[0.4em] text-gold mb-5">Boutique • Est. Daharanwala</p>
            <h1
              className="font-urdu text-5xl md:text-6xl lg:text-7xl text-primary leading-[1.4] font-semibold"
              style={{ direction: "rtl" }}
            >
              پاکستانی فیشن کا<br />
              <span className="gold-gradient-text">نیا انداز</span>
            </h1>
            <h2 className="font-serif text-2xl md:text-3xl text-foreground/80 mt-6 leading-snug">
              Ladies, Gents, Stitched & Premium Fashion <br className="hidden md:block" />
              Collection for Every Occasion.
            </h2>
            <p className="text-foreground/60 mt-5 max-w-md leading-relaxed">
              Discover hand-picked, ethically sourced and beautifully tailored Pakistani attire — crafted for the modern family.
            </p>
            <div className="flex flex-wrap gap-3 mt-8">
              <Link
                to="/shop"
                className="inline-flex items-center gap-2 bg-primary text-cream px-7 py-3.5 rounded-full font-medium hover:bg-gold hover:text-primary transition-all luxury-shadow"
              >
                <ShoppingBag size={18} /> Shop Now
              </Link>
              <a
                href={whatsappLink("Assalam o Alaikum, I want to place an order.")}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 bg-cream border border-primary/20 text-primary px-7 py-3.5 rounded-full font-medium hover:bg-primary hover:text-cream transition"
              >
                Order on WhatsApp
              </a>
            </div>
            <div className="flex items-center gap-6 mt-10 text-sm text-foreground/70">
              <div className="flex items-center gap-1.5">
                {[...Array(5)].map((_, i) => <Star key={i} size={14} className="fill-gold text-gold" />)}
                <span className="ml-1">5,000+ Happy Customers</span>
              </div>
            </div>
          </div>
          <div className="order-1 lg:order-2 relative">
            <div className="absolute -inset-4 bg-gradient-to-br from-gold/30 to-transparent rounded-full blur-3xl" />
            <div className="relative aspect-[4/5] rounded-sm overflow-hidden luxury-shadow">
              <img src={hero} alt="Pakistani fashion model in emerald embroidered dress" className="w-full h-full object-cover" />
              <div className="absolute bottom-6 left-6 right-6 bg-cream/95 backdrop-blur p-4 flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-primary text-cream flex items-center justify-center font-serif text-lg">N</div>
                <div>
                  <p className="text-xs uppercase tracking-widest text-gold">New Arrival</p>
                  <p className="font-serif text-primary">Festive Collection 2026</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="container mx-auto px-6 py-20">
        <SectionTitle eyebrow="Explore" title="Featured Categories" urdu="ہماری کلیکشنز" />
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
          {CATEGORIES.map((c) => (
            <Link
              key={c.slug}
              to="/shop"
              className="group relative aspect-[3/4] overflow-hidden rounded-sm bg-secondary"
            >
              <img src={c.image} alt={c.name} loading="lazy" className="w-full h-full object-cover transition-transform duration-[1500ms] group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/90 via-primary/30 to-transparent" />
              <div className="absolute inset-0 p-4 md:p-6 flex flex-col justify-end text-cream">
                <p className="font-urdu text-lg md:text-xl text-gold-soft" style={{ direction: "rtl" }}>{c.nameUr}</p>
                <h3 className="font-serif text-xl md:text-2xl">{c.name}</h3>
                <p className="text-xs text-cream/70 mt-1">{c.count} products</p>
                <span className="inline-flex items-center gap-1 text-xs uppercase tracking-widest text-gold mt-3 group-hover:gap-2 transition-all">
                  Shop <ArrowRight size={12} />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* FEATURED PRODUCTS */}
      <section className="bg-secondary/50 py-20">
        <div className="container mx-auto px-6">
          <SectionTitle eyebrow="Handpicked" title="Featured Products" urdu="منتخب مصنوعات" />
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {featured.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
          <div className="text-center mt-12">
            <Link to="/shop" className="inline-flex items-center gap-2 text-primary font-medium border-b border-gold pb-1 hover:gap-3 transition-all">
              View Full Collection <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="container mx-auto px-6 py-20">
        <SectionTitle eyebrow="Our Promise" title="Why Choose Us" urdu="ہم کیوں منتخب کریں" />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {[
            { icon: Award, title: "Premium Quality Products", desc: "Hand-selected fabrics and refined finishing on every piece." },
            { icon: Sparkles, title: "Latest Fashion Trends", desc: "Fresh collections aligned with seasonal Pakistani fashion." },
            { icon: ShoppingBag, title: "Easy Online Ordering", desc: "Browse, add to cart, or order directly via WhatsApp." },
            { icon: HeadphonesIcon, title: "Fast Customer Support", desc: "Friendly help, every day from 10 AM – 9 PM." },
            { icon: Star, title: "Trusted Boutique Experience", desc: "Years of serving families across Pakistan." },
            { icon: Shield, title: "Secure Shopping Experience", desc: "Safe checkout and trusted, transparent service." },
          ].map((f) => (
            <div key={f.title} className="group p-7 bg-card rounded-sm border border-border hover:border-gold transition-all hover:luxury-shadow">
              <div className="w-12 h-12 rounded-full bg-primary/5 text-primary flex items-center justify-center mb-4 group-hover:bg-gold group-hover:text-primary transition">
                <f.icon size={22} />
              </div>
              <h3 className="font-serif text-xl text-primary mb-2">{f.title}</h3>
              <p className="text-sm text-foreground/65 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* BEST SELLERS */}
      <section className="bg-primary text-cream py-20">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <p className="text-xs uppercase tracking-[0.4em] text-gold mb-3">Top Picks</p>
            <h2 className="font-serif text-3xl md:text-5xl text-cream leading-tight">Best Sellers</h2>
            <p className="font-urdu text-xl md:text-2xl text-gold-soft mt-3" style={{ direction: "rtl" }}>سب سے زیادہ پسندیدہ</p>
            <div className="gold-divider w-24 mt-5 mx-auto" />
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {bestSellers.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="container mx-auto px-6 py-20">
        <SectionTitle eyebrow="Loved By" title="Customer Testimonials" urdu="ہمارے گاہکوں کی رائے" />
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { name: "Ayesha Khan", city: "Lahore", text: "Excellent quality and beautiful designs. The embroidery is just stunning. Highly recommended." },
            { name: "Hassan Raza", city: "Karachi", text: "Ordered a kurta for Eid and it arrived perfectly stitched. Delivery was on time, will order again." },
            { name: "Fatima Bibi", city: "Multan", text: "The lawn collection is breathtaking. Fabric quality is premium and prices are reasonable." },
          ].map((t) => (
            <div key={t.name} className="bg-card border border-border p-7 rounded-sm hover:luxury-shadow transition">
              <div className="flex gap-0.5 mb-4">{[...Array(5)].map((_, i) => <Star key={i} size={16} className="fill-gold text-gold" />)}</div>
              <p className="text-foreground/75 leading-relaxed italic">"{t.text}"</p>
              <div className="mt-5 pt-5 border-t border-border">
                <p className="font-serif text-lg text-primary">{t.name}</p>
                <p className="text-xs text-muted-foreground uppercase tracking-widest">{t.city}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SHOWCASE */}
      <section className="relative py-20 bg-cream">
        <div className="container mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center">
          <div className="relative aspect-[4/3] rounded-sm overflow-hidden luxury-shadow">
            <img src={showcase} alt="Pakistani family fashion showcase" loading="lazy" className="w-full h-full object-cover" />
          </div>
          <div>
            <p className="text-xs uppercase tracking-[0.4em] text-gold mb-3">Fashion For Everyone</p>
            <h2 className="font-serif text-3xl md:text-5xl text-primary leading-tight">Dress the Whole Family in Elegance</h2>
            <p className="font-urdu text-xl md:text-2xl text-foreground/70 mt-3" style={{ direction: "rtl" }}>پورے خاندان کے لیے فیشن</p>
            <div className="gold-divider w-24 my-6" />
            <div className="grid grid-cols-2 gap-4 mt-6">
              {["Ladies Fashion", "Gents Fashion", "Family Collection", "Seasonal Collection"].map((t) => (
                <div key={t} className="border border-border p-4 rounded-sm hover:border-gold transition">
                  <p className="font-serif text-primary">{t}</p>
                </div>
              ))}
            </div>
            <Link to="/categories" className="inline-flex mt-8 items-center gap-2 bg-primary text-cream px-7 py-3 rounded-full hover:bg-gold hover:text-primary transition">
              Browse Collections <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* WHATSAPP CTA */}
      <section className="bg-whatsapp text-white py-20">
        <div className="container mx-auto px-6 text-center max-w-3xl">
          <svg viewBox="0 0 24 24" width="56" height="56" className="mx-auto mb-5" fill="currentColor"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 2.1.55 4.15 1.6 5.95L2 22l4.25-1.11a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.84 9.84 0 0 0 12.04 2z"/></svg>
          <h2 className="font-serif text-3xl md:text-5xl">Order Directly on WhatsApp</h2>
          <p className="font-urdu text-xl mt-3 text-white/90" style={{ direction: "rtl" }}>براہِ راست واٹس ایپ پر آرڈر کریں</p>
          <p className="mt-5 text-white/85 max-w-xl mx-auto">Quick. Personal. Hassle-free. Send us your favourite designs and we'll confirm availability, sizing and delivery within minutes.</p>
          <a
            href={whatsappLink("Assalam o Alaikum, I want to place an order from New Sitara Boutique.")}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 mt-8 bg-white text-whatsapp px-8 py-4 rounded-full font-semibold hover:bg-cream transition"
          >
            Chat on WhatsApp Now
          </a>
        </div>
      </section>

      {/* NEWSLETTER */}
      <section className="container mx-auto px-6 py-20">
        <div className="bg-card border border-border p-10 md:p-16 rounded-sm text-center max-w-3xl mx-auto">
          <p className="text-xs uppercase tracking-[0.4em] text-gold mb-3">Newsletter</p>
          <h2 className="font-serif text-3xl md:text-4xl text-primary">Stay Updated with New Arrivals</h2>
          <p className="text-foreground/65 mt-3">Subscribe for early access to seasonal drops and exclusive offers.</p>
          <form
            onSubmit={(e) => { e.preventDefault(); (e.target as HTMLFormElement).reset(); }}
            className="mt-6 flex flex-col sm:flex-row gap-3 max-w-md mx-auto"
          >
            <input
              type="email"
              required
              placeholder="Your email address"
              maxLength={120}
              className="flex-1 bg-cream border border-border px-5 py-3 rounded-full focus:outline-none focus:border-gold"
            />
            <button className="bg-primary text-cream px-7 py-3 rounded-full hover:bg-gold hover:text-primary transition">Subscribe</button>
          </form>
        </div>
      </section>

      {/* ABOUT PREVIEW */}
      <section className="container mx-auto px-6 pb-20">
        <div className="bg-primary text-cream rounded-sm p-10 md:p-16 text-center">
          <p className="font-urdu text-2xl md:text-3xl text-gold mb-3" style={{ direction: "rtl" }}>ہمارے بارے میں</p>
          <h2 className="font-serif text-3xl md:text-4xl">About New Sitara Boutique Center</h2>
          <div className="gold-divider w-24 mx-auto my-5" />
          <p className="max-w-2xl mx-auto text-cream/80 leading-relaxed">
            Rooted in Daharanwala, New Sitara Boutique Center has been serving Pakistani families with refined, occasion-ready fashion for years.
            From everyday wear to bridal statements, every piece is hand-checked to honour our promise of quality.
          </p>
          <Link to="/about" className="inline-flex mt-7 items-center gap-2 border border-gold text-gold px-7 py-3 rounded-full hover:bg-gold hover:text-primary transition">
            Read Our Story <ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </div>
  );
}
