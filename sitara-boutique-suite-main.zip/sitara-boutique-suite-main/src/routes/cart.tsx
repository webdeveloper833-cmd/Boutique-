import { createFileRoute, Link } from "@tanstack/react-router";
import { Minus, Plus, ShoppingBag, Trash2 } from "lucide-react";
import { useCart } from "@/lib/cart";
import { formatPKR, whatsappLink } from "@/lib/products";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Cart — New Sitara Boutique Center" },
      { name: "description", content: "Review your shopping cart and checkout via WhatsApp." },
    ],
  }),
  component: Cart,
});

function Cart() {
  const { items, setQty, remove, total, clear } = useCart();

  const message = `Assalam o Alaikum, I want to order:%0A${items
    .map((i) => `• ${i.product.name} x ${i.qty} — ${formatPKR(i.product.price * i.qty)}`)
    .join("%0A")}%0A%0ATotal: ${formatPKR(total)}`;

  return (
    <div className="container mx-auto px-6 py-16 min-h-[60vh]">
      <h1 className="font-serif text-4xl md:text-5xl text-primary mb-2">Shopping Cart</h1>
      <p className="font-urdu text-xl text-foreground/70" style={{ direction: "rtl" }}>آپ کی خریداری کی فہرست</p>
      <div className="gold-divider w-24 my-6" />

      {items.length === 0 ? (
        <div className="text-center py-20">
          <ShoppingBag size={48} className="mx-auto text-muted-foreground mb-4" />
          <p className="text-foreground/70 mb-6">Your cart is empty.</p>
          <Link to="/shop" className="inline-flex bg-primary text-cream px-7 py-3 rounded-full hover:bg-gold hover:text-primary transition">
            Start Shopping
          </Link>
        </div>
      ) : (
        <div className="grid lg:grid-cols-[1fr_360px] gap-10">
          <div className="space-y-4">
            {items.map((i) => (
              <div key={i.product.id} className="flex gap-4 bg-card border border-border p-4 rounded-sm">
                <img src={i.product.image} alt={i.product.name} className="w-24 h-32 object-cover rounded-sm" />
                <div className="flex-1">
                  <h3 className="font-serif text-lg text-primary">{i.product.name}</h3>
                  <p className="text-xs uppercase tracking-widest text-muted-foreground">{i.product.category}</p>
                  <p className="text-primary font-semibold mt-2">{formatPKR(i.product.price)}</p>
                  <div className="flex items-center gap-4 mt-3">
                    <div className="flex items-center border border-border rounded-sm">
                      <button onClick={() => setQty(i.product.id, i.qty - 1)} className="p-2 hover:bg-secondary"><Minus size={14} /></button>
                      <span className="px-3 text-sm">{i.qty}</span>
                      <button onClick={() => setQty(i.product.id, i.qty + 1)} className="p-2 hover:bg-secondary"><Plus size={14} /></button>
                    </div>
                    <button onClick={() => remove(i.product.id)} className="text-destructive flex items-center gap-1 text-sm hover:underline">
                      <Trash2 size={14} /> Remove
                    </button>
                  </div>
                </div>
              </div>
            ))}
            <button onClick={clear} className="text-sm text-muted-foreground hover:text-destructive">Clear cart</button>
          </div>
          <aside className="bg-card border border-border p-6 rounded-sm h-fit sticky top-28">
            <h3 className="font-serif text-xl text-primary mb-4">Order Summary</h3>
            <div className="flex justify-between text-sm py-2 border-b border-border"><span>Subtotal</span><span>{formatPKR(total)}</span></div>
            <div className="flex justify-between text-sm py-2 border-b border-border"><span>Shipping</span><span className="text-gold">Calculated on WhatsApp</span></div>
            <div className="flex justify-between text-lg font-semibold py-4"><span>Total</span><span className="text-primary">{formatPKR(total)}</span></div>
            <a
              href={`https://wa.me/923000000000?text=${message}`}
              target="_blank"
              rel="noreferrer"
              className="block w-full bg-whatsapp text-white text-center py-3 rounded-full font-medium hover:opacity-90 transition"
            >
              Checkout via WhatsApp
            </a>
            <Link to="/shop" className="block text-center text-sm text-muted-foreground mt-3 hover:text-primary">Continue shopping</Link>
          </aside>
        </div>
      )}
    </div>
  );
}