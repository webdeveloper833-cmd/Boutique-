import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { CATEGORIES, PRODUCTS } from "@/lib/products";
import { ProductCard } from "@/components/ProductCard";

export const Route = createFileRoute("/shop")({
  head: () => ({
    meta: [
      { title: "Shop — New Sitara Boutique Center" },
      { name: "description", content: "Shop our full collection of Pakistani ladies, gents and unstitched fashion online." },
      { property: "og:title", content: "Shop — New Sitara Boutique" },
      { property: "og:description", content: "Browse our complete Pakistani fashion collection." },
    ],
  }),
  component: Shop,
});

function Shop() {
  const [cat, setCat] = useState<string>("all");
  const [sort, setSort] = useState<string>("featured");
  const [q, setQ] = useState("");

  const products = useMemo(() => {
    let list = PRODUCTS.filter((p) => (cat === "all" ? true : p.category === cat));
    if (q.trim()) {
      const t = q.toLowerCase();
      list = list.filter((p) => p.name.toLowerCase().includes(t));
    }
    if (sort === "price-asc") list = [...list].sort((a, b) => a.price - b.price);
    if (sort === "price-desc") list = [...list].sort((a, b) => b.price - a.price);
    if (sort === "sale") list = [...list].sort((a, b) => Number(!!b.badge) - Number(!!a.badge));
    return list;
  }, [cat, sort, q]);

  return (
    <div>
      <section className="bg-primary text-cream py-16">
        <div className="container mx-auto px-6 text-center">
          <p className="text-xs uppercase tracking-[0.4em] text-gold mb-2">Boutique</p>
          <h1 className="font-serif text-4xl md:text-6xl">Shop the Collection</h1>
          <p className="font-urdu text-xl mt-2 text-gold-soft" style={{ direction: "rtl" }}>تمام مصنوعات</p>
        </div>
      </section>

      <section className="container mx-auto px-4 md:px-6 py-12">
        <div className="grid lg:grid-cols-[240px_1fr] gap-8">
          <aside className="space-y-8">
            <div>
              <h3 className="font-serif text-lg text-primary mb-3">Search</h3>
              <div className="relative">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value.slice(0, 80))}
                  placeholder="Search products"
                  className="w-full bg-card border border-border pl-9 pr-3 py-2.5 rounded-sm focus:outline-none focus:border-gold"
                />
              </div>
            </div>
            <div>
              <h3 className="font-serif text-lg text-primary mb-3">Categories</h3>
              <ul className="space-y-1.5 text-sm">
                {[{ slug: "all", name: "All Products" }, ...CATEGORIES.map((c) => ({ slug: c.slug, name: c.name }))].map((c) => (
                  <li key={c.slug}>
                    <button
                      onClick={() => setCat(c.slug)}
                      className={`w-full text-left px-3 py-2 rounded-sm transition ${cat === c.slug ? "bg-primary text-cream" : "hover:bg-secondary"}`}
                    >
                      {c.name}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="font-serif text-lg text-primary mb-3">Sort By</h3>
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value)}
                className="w-full bg-card border border-border px-3 py-2.5 rounded-sm focus:outline-none focus:border-gold"
              >
                <option value="featured">Featured</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="sale">On Sale</option>
              </select>
            </div>
          </aside>

          <div>
            <p className="text-sm text-muted-foreground mb-5">{products.length} products</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
              {products.map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
            {products.length === 0 && (
              <p className="text-center text-muted-foreground py-20">No products match your filters.</p>
            )}
            <div className="flex justify-center gap-2 mt-12">
              {[1, 2, 3].map((n) => (
                <button key={n} className={`w-10 h-10 rounded-sm border ${n === 1 ? "bg-primary text-cream border-primary" : "border-border hover:border-gold"}`}>{n}</button>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}