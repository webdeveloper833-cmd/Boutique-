import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Clock, Mail, MapPin, Phone } from "lucide-react";
import { whatsappLink } from "@/lib/products";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — New Sitara Boutique Center" },
      { name: "description", content: "Get in touch with New Sitara Boutique Center in Daharanwala. Phone, WhatsApp, email and visit." },
      { property: "og:title", content: "Contact — New Sitara Boutique" },
      { property: "og:description", content: "Get in touch with our boutique team." },
    ],
  }),
  component: Contact,
});

function Contact() {
  const [sent, setSent] = useState(false);
  return (
    <div>
      <section className="bg-primary text-cream py-16">
        <div className="container mx-auto px-6 text-center">
          <p className="text-xs uppercase tracking-[0.4em] text-gold mb-2">Reach Out</p>
          <h1 className="font-serif text-4xl md:text-6xl">Contact Us</h1>
          <p className="font-urdu text-xl mt-2 text-gold-soft" style={{ direction: "rtl" }}>ہم سے رابطہ کریں</p>
        </div>
      </section>

      <section className="container mx-auto px-6 py-16 grid lg:grid-cols-2 gap-10">
        <div>
          <h2 className="font-serif text-3xl text-primary mb-2">Send us a Message</h2>
          <p className="text-foreground/65 mb-6">Have a question about a product or order? We'll get back within 24 hours.</p>
          {sent ? (
            <div className="bg-card border border-gold p-6 rounded-sm">
              <p className="font-serif text-primary text-lg">Thank you! We've received your message.</p>
              <p className="text-sm text-foreground/65 mt-1">Our team will get back to you shortly.</p>
            </div>
          ) : (
            <form
              onSubmit={(e) => { e.preventDefault(); setSent(true); }}
              className="space-y-4"
            >
              <div className="grid sm:grid-cols-2 gap-4">
                <input required maxLength={80} placeholder="Your Name" className="bg-card border border-border px-4 py-3 rounded-sm focus:outline-none focus:border-gold" />
                <input required type="tel" maxLength={20} placeholder="Phone Number" className="bg-card border border-border px-4 py-3 rounded-sm focus:outline-none focus:border-gold" />
              </div>
              <input required type="email" maxLength={120} placeholder="Email Address" className="w-full bg-card border border-border px-4 py-3 rounded-sm focus:outline-none focus:border-gold" />
              <input maxLength={120} placeholder="Subject" className="w-full bg-card border border-border px-4 py-3 rounded-sm focus:outline-none focus:border-gold" />
              <textarea required maxLength={1000} rows={5} placeholder="Your message" className="w-full bg-card border border-border px-4 py-3 rounded-sm focus:outline-none focus:border-gold" />
              <button className="bg-primary text-cream px-7 py-3 rounded-full hover:bg-gold hover:text-primary transition">Send Message</button>
            </form>
          )}
        </div>

        <div className="space-y-5">
          <div className="bg-card border border-border p-6 rounded-sm flex gap-4">
            <MapPin className="text-gold shrink-0" />
            <div>
              <h3 className="font-serif text-lg text-primary">Visit Us</h3>
              <p className="text-foreground/70 text-sm">Main Bazaar, Daharanwala,<br />Punjab, Pakistan</p>
            </div>
          </div>
          <div className="bg-card border border-border p-6 rounded-sm flex gap-4">
            <Phone className="text-gold shrink-0" />
            <div>
              <h3 className="font-serif text-lg text-primary">Call / WhatsApp</h3>
              <p className="text-foreground/70 text-sm">+92 300 0000000</p>
              <a href={whatsappLink("Assalam o Alaikum")} className="text-whatsapp text-sm hover:underline">Chat on WhatsApp →</a>
            </div>
          </div>
          <div className="bg-card border border-border p-6 rounded-sm flex gap-4">
            <Mail className="text-gold shrink-0" />
            <div>
              <h3 className="font-serif text-lg text-primary">Email</h3>
              <p className="text-foreground/70 text-sm">info@newsitara.com</p>
            </div>
          </div>
          <div className="bg-card border border-border p-6 rounded-sm flex gap-4">
            <Clock className="text-gold shrink-0" />
            <div>
              <h3 className="font-serif text-lg text-primary">Business Hours</h3>
              <p className="text-foreground/70 text-sm">Mon – Sat: 10:00 AM – 9:00 PM</p>
              <p className="text-foreground/70 text-sm">Sunday: 2:00 PM – 9:00 PM</p>
            </div>
          </div>
          <div className="aspect-video rounded-sm overflow-hidden border border-border bg-secondary flex items-center justify-center relative">
            <iframe
              title="Map"
              src="https://www.google.com/maps?q=Daharanwala,Pakistan&output=embed"
              className="absolute inset-0 w-full h-full grayscale-[20%]"
              loading="lazy"
            />
          </div>
        </div>
      </section>
    </div>
  );
}